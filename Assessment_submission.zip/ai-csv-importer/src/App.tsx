import React, { useState } from "react";
import {
  LayoutDashboard,
  Users,
  Briefcase,
  Layers,
  Settings,
  Phone,
  MessageSquare,
  Compass,
  FileCode,
  Bell,
  Search,
  User,
  AlertCircle,
  HelpCircle,
  CloudLightning,
  ChevronRight,
  Database
} from "lucide-react";
import UploadStep from "./components/UploadStep";
import PreviewStep from "./components/PreviewStep";
import ProgressStep from "./components/ProgressStep";
import ResultStep from "./components/ResultStep";
import { CRMRecord, SkipReason } from "./types";

type StepType = "upload" | "preview" | "processing" | "results";

export default function App() {
  const [step, setStep] = useState<StepType>("upload");
  const [fileName, setFileName] = useState("");
  const [headers, setHeaders] = useState<string[]>([]);
  const [rows, setRows] = useState<Record<string, string>[]>([]);
  const [successfulRecords, setSuccessfulRecords] = useState<CRMRecord[]>([]);
  const [skippedRecords, setSkippedRecords] = useState<SkipReason[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleCSVParsed = (name: string, csvHeaders: string[], csvRows: Record<string, string>[]) => {
    setFileName(name);
    setHeaders(csvHeaders);
    setRows(csvRows);
    setStep("preview");
    setErrorMsg(null);
  };

  const handleConfirmImport = () => {
    setStep("processing");
    setErrorMsg(null);
  };

  const handleProcessingCompleted = (successful: CRMRecord[], skipped: SkipReason[]) => {
    setSuccessfulRecords(successful);
    setSkippedRecords(skipped);
    setStep("results");
  };

  const handleCancelProcessing = () => {
    setStep("preview");
  };

  const handleReset = () => {
    setStep("upload");
    setFileName("");
    setHeaders([]);
    setRows([]);
    setSuccessfulRecords([]);
    setSkippedRecords([]);
    setErrorMsg(null);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex" id="groweasy-dashboard-wrapper">
      {/* 1. Left Sidebar (Authentic CRM sidebar context) */}
      <aside className="w-64 bg-white border-r border-slate-100 hidden md:flex flex-col shrink-0" id="crm-sidebar">
        {/* GrowEasy Logo Header */}
        <div className="p-6 border-b border-slate-100 flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold text-base shadow-sm shadow-emerald-200">
            GE
          </div>
          <div>
            <h1 className="text-sm font-sans font-bold text-slate-800 tracking-tight leading-none">GrowEasy</h1>
            <span className="text-[10px] text-emerald-600 font-medium tracking-wide uppercase">CRM Platform</span>
          </div>
        </div>

        {/* User Card / Selector */}
        <div className="p-4 mx-3 my-4 bg-slate-50 rounded-xl flex items-center justify-between border border-slate-100/50">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="h-8 w-8 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 shrink-0">
              <User className="h-4 w-4" />
            </div>
            <div className="overflow-hidden">
              <p className="text-xs font-semibold text-slate-700 truncate leading-tight">Vaibhav</p>
              <p className="text-[10px] text-slate-400 font-mono tracking-tight uppercase">Owner</p>
            </div>
          </div>
          <ChevronRight className="h-3.5 w-3.5 text-slate-400" />
        </div>

        {/* Sidebar Nav Links */}
        <nav className="flex-1 px-4 space-y-1">
          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">Main Menu</p>
          
          <a href="#dashboard" className="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-slate-600 rounded-lg text-xs font-medium transition-colors">
            <LayoutDashboard className="h-4 w-4" />
            Dashboard
          </a>
          
          <a href="#leads" className="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-slate-600 rounded-lg text-xs font-medium transition-colors">
            <Users className="h-4 w-4" />
            Generate Leads
          </a>

          <a href="#manage" className="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-slate-600 rounded-lg text-xs font-medium transition-colors">
            <Briefcase className="h-4 w-4" />
            Manage Leads
          </a>

          <a href="#engage" className="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-slate-600 rounded-lg text-xs font-medium transition-colors">
            <Layers className="h-4 w-4" />
            Engage Leads
          </a>

          <div className="h-px bg-slate-100 my-4" />

          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-3 mb-2">Control Center</p>

          <a href="#sources" className="flex items-center gap-3 px-3 py-2 bg-emerald-50 text-emerald-700 rounded-xl text-xs font-semibold border border-emerald-100/50">
            <Database className="h-4 w-4 text-emerald-600" />
            Lead Sources
          </a>

          <a href="#whatsapp" className="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-slate-600 rounded-lg text-xs font-medium transition-colors">
            <MessageSquare className="h-4 w-4" />
            WhatsApp Account
          </a>

          <a href="#telecalling" className="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-slate-600 rounded-lg text-xs font-medium transition-colors">
            <Phone className="h-4 w-4" />
            Tele Calling
          </a>

          <a href="#crmfields" className="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-slate-600 rounded-lg text-xs font-medium transition-colors">
            <Settings className="h-4 w-4" />
            CRM Fields
          </a>

          <a href="#api" className="flex items-center gap-3 px-3 py-2 text-slate-400 hover:text-slate-600 rounded-lg text-xs font-medium transition-colors">
            <FileCode className="h-4 w-4" />
            API Center
          </a>
        </nav>

        {/* Sidebar Footer Info */}
        <div className="p-4 border-t border-slate-100 text-[10px] text-slate-400 text-center flex items-center justify-center gap-1.5 font-mono">
          <CloudLightning className="h-3 w-3 text-emerald-500 animate-pulse" />
          Powered by Gemini AI
        </div>
      </aside>

      {/* 2. Main Work Area */}
      <div className="flex-1 flex flex-col min-w-0" id="crm-main-container">
        {/* Top Navbar */}
        <header className="bg-white border-b border-slate-100 h-16 flex items-center justify-between px-6 shrink-0" id="crm-navbar">
          <div className="flex items-center gap-3 w-72">
            <div className="relative w-full">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search resources, clients, docs..."
                className="w-full pl-9 pr-3 py-1.5 border border-slate-150 bg-slate-50/50 rounded-lg text-xs focus:outline-none focus:bg-white"
                disabled
              />
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button type="button" className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg relative">
              <Bell className="h-4.5 w-4.5" />
              <span className="absolute top-1 right-1 h-1.5 w-1.5 bg-rose-500 rounded-full" />
            </button>
            <button type="button" className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg">
              <HelpCircle className="h-4.5 w-4.5" />
            </button>
            <div className="h-8 w-px bg-slate-100" />
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-full bg-emerald-600 flex items-center justify-center text-white text-xs font-bold font-mono">
                V
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-xs font-semibold text-slate-700 leading-tight">Vaibhav</p>
                <p className="text-[10px] text-slate-400">vaibhavadhe@gmail.com</p>
              </div>
            </div>
          </div>
        </header>

        {/* Workspace Scroll Area */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8" id="crm-workspace-scroll">
          <div className="max-w-6xl mx-auto space-y-6">
            
            {/* Global Error message Banner */}
            {errorMsg && (
              <div className="p-4 bg-rose-50 border border-rose-100 rounded-2xl flex items-start gap-3 text-rose-800 text-xs animate-slide-in" id="global-error-banner">
                <AlertCircle className="h-5 w-5 text-rose-500 shrink-0" />
                <div className="space-y-1">
                  <p className="font-semibold">Operation failed</p>
                  <p className="text-rose-600 leading-normal">{errorMsg}</p>
                </div>
              </div>
            )}

            {/* Importer Steps Controller widget */}
            <div className="bg-white border border-slate-100 rounded-3xl p-6 md:p-8 shadow-sm">
              
              {/* Process step pipeline tracker */}
              {step !== "processing" && (
                <div className="flex items-center justify-between max-w-md mx-auto mb-10 text-xs text-slate-400 font-semibold" id="importer-steps-pipeline">
                  <div className="flex items-center gap-2">
                    <span className={`h-6 w-6 rounded-full flex items-center justify-center text-[11px] ${step === "upload" ? "bg-emerald-600 text-white shadow-sm" : "bg-emerald-100 text-emerald-700"}`}>1</span>
                    <span className={step === "upload" ? "text-slate-800 font-semibold" : "text-slate-500"}>Upload</span>
                  </div>
                  <div className="h-px bg-slate-200 flex-1 mx-3" />
                  <div className="flex items-center gap-2">
                    <span className={`h-6 w-6 rounded-full flex items-center justify-center text-[11px] ${step === "preview" ? "bg-emerald-600 text-white shadow-sm" : step === "results" ? "bg-emerald-100 text-emerald-700" : "bg-slate-100 text-slate-400"}`}>2</span>
                    <span className={step === "preview" ? "text-slate-800 font-semibold" : step === "results" ? "text-slate-500" : "text-slate-400"}>Verify</span>
                  </div>
                  <div className="h-px bg-slate-200 flex-1 mx-3" />
                  <div className="flex items-center gap-2">
                    <span className={`h-6 w-6 rounded-full flex items-center justify-center text-[11px] ${step === "results" ? "bg-emerald-600 text-white shadow-sm" : "bg-slate-100 text-slate-400"}`}>3</span>
                    <span className={step === "results" ? "text-slate-800 font-semibold" : "text-slate-400"}>Mapped Leads</span>
                  </div>
                </div>
              )}

              {/* Dynamic steps renderer */}
              {step === "upload" && (
                <UploadStep
                  onCSVParsed={handleCSVParsed}
                  onError={(msg) => setErrorMsg(msg)}
                />
              )}

              {step === "preview" && (
                <PreviewStep
                  fileName={fileName}
                  headers={headers}
                  rows={rows}
                  onBack={handleReset}
                  onConfirm={handleConfirmImport}
                />
              )}

              {step === "processing" && (
                <ProgressStep
                  rows={rows}
                  batchSize={10}
                  onCompleted={handleProcessingCompleted}
                  onCancel={handleCancelProcessing}
                />
              )}

              {step === "results" && (
                <ResultStep
                  successful={successfulRecords}
                  skipped={skippedRecords}
                  onReset={handleReset}
                />
              )}

            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
